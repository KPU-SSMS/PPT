package www.bank_wait.co.kr.bank_wait;


public class MapApiConst {
	// http://developers.daum.net/console
    public static final String DAUM_MAPS_ANDROID_APP_API_KEY = "6f504f9b73ad280372b2aff0036b6f32";
}
