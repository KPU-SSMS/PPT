package www.bank_wait.co.kr.bank_wait;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class ReserveActivity extends AppCompatActivity {

    private static String TAG = "Reserve_Activity";

    private static final String TAG_JSON="result";
    private static final String TAG_BANK = "bank_name"; //은행이름
    private static final String TAG_BANK_WAIT_RANK = "bank_wait_rank";//사용자 대기번호
    private static final String TAG_RESERVE_NUM = "reserve_num";//은행에서 발권한 총 대기표수
    private static final String TAG_NOWRESERVE_NUM ="now_reserve_num";// 은행에서 처리중인 대기표 번호

    Thread th;
    int time_count =180;
    JSONArray json_data = null;
    TextView mTextViewResult;
    ArrayList<HashMap<String, String>> mArrayList;
    String mJsonString;
    String bank_no = "9999";

    TextView tv_bankName;
    TextView tv_reserveNum;
    TextView tv_nowReserveNum;
    TextView tv_waitNum;
    TextView tv_waitTime;


    Button btn_cancle;
    Button btn_reserve;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserve);


        mTextViewResult = (TextView)findViewById(R.id.text_1_1);
        tv_bankName = (TextView)findViewById(R.id.tv_bankName);
        tv_reserveNum = (TextView)findViewById(R.id.tv_reserveNum);
        tv_nowReserveNum = (TextView)findViewById(R.id.tv_nowReserveNum);
        tv_waitNum = (TextView)findViewById(R.id.tv_waitNum);
        tv_waitTime = (TextView)findViewById(R.id.tv_waitTime);

        btn_cancle = (Button)findViewById(R.id.btn_reserveCancle);
       btn_reserve = (Button)findViewById(R.id.btn_reinsert);


        mArrayList = new ArrayList<>();

        /*th = new Thread(new Runnable() {
            int min;
            int sec;
            @Override
            public void run() {
                boolean th_bl =true;
                while (th_bl){
                    try {
                        if(time_count > 0) {
                            Thread.sleep(1000);
                            sec = time_count % 60;
                            min = (time_count - sec) / 60;

                            tv_waitTime.setText(min + ":" + sec);
                            time_count--;
                        }else if(time_count < 1){
                            th_bl = false;
                        }

                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }
        });*/
        //th.start();
        GetData task = new GetData();
        task.execute("http://35.189.148.163/get_reserve.php",null);

        btn_reserve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetData getData = new GetData();
                getData.execute("http://35.189.148.163/reserve_reinsert.php","1");
            }
        });

        btn_cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetData task = new GetData();
                task.execute("http://35.189.148.163/reserve_cancle.php","2");
                //Intent intent = new Intent(ReserveActivity.this,dialog.class);
                //startActivity(intent);
                Toast.makeText(ReserveActivity.this,"취소되었습니다.",Toast.LENGTH_SHORT).show();
                finish();
            }
        });



    }

    private class GetData extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;
        String errorString = null;
        int url_flag = 0;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();


    }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);



            //mTextViewResult.setText(result);
            Log.d(TAG, "response  - " + result);

            if (result == null){

                Toast.makeText(ReserveActivity.this, "에러가 발생하였습니다.", Toast.LENGTH_SHORT).show();
            }
            else {
                tv_bankName.setText(result);
                //Toast.makeText(ReserveActivity.this, result, Toast.LENGTH_SHORT).show();
                if(result.equals("code001")){
                    finish();
                    Toast.makeText(ReserveActivity.this,"예약된정보가 없습니다.",Toast.LENGTH_LONG).show();
                }else {
                    mJsonString = result;
                    if (url_flag ==0) {
                        showResult();
                    }else if(url_flag == 1){
                        if (result.equals("1")){
                            Toast.makeText(getApplicationContext(),"재발급 되었습니다.",Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(ReserveActivity.this,ReserveActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }else if(url_flag == 2){
                        if (result.equals("1")){
                            Toast.makeText(getApplicationContext(),"예약이 취소 되었습니다.",Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(ReserveActivity.this,MainActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }
                }
            }
        }


        @Override
        protected String doInBackground(String... params) {

            String serverURL = params[0];
            serverURL += "?id=" +getIDPreference();
            if(params[1] == null) {

            }else if (params[1].equals("1")){
                serverURL += "&bankNo=" + params[1];
                Log.d("서버 주소", serverURL);
                url_flag =1;
            }else if (params[1].equals("2")){
                serverURL += "&bankNo=" + params[1];
                Log.d("서버 주소", serverURL);
                url_flag =2;
            }
            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.connect();


                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }


                bufferedReader.close();


                return sb.toString().trim();

            } catch (Exception e) {

                Log.d(TAG, "InsertData: Error ", e);
                errorString = e.toString();

                return null;
            }

        }
    }


    protected void showResult() {
        try {
            JSONObject jsonObj = new JSONObject(mJsonString);
             json_data = jsonObj.getJSONArray(TAG_JSON);
             int wait_time = 0;
             int nowReserveNum = 0;

                JSONObject c = json_data.getJSONObject(0);
                String m_name = c.getString(TAG_BANK);
                String reserve_num = c.getString(TAG_RESERVE_NUM);
                String now_reserve_num = c.getString(TAG_NOWRESERVE_NUM);
                String bank_wait_rank = c.getString(TAG_BANK_WAIT_RANK);
                bank_no = c.getString("bank_no");

                tv_bankName.setText(m_name);
                tv_waitNum.setText(bank_wait_rank);
                nowReserveNum = Integer.parseInt(reserve_num) - Integer.parseInt(bank_wait_rank);
                tv_nowReserveNum.setText(String.valueOf(nowReserveNum));
                tv_reserveNum.setText(reserve_num);
                wait_time = 3 * Integer.parseInt(bank_wait_rank);
                tv_waitTime.setText(String.valueOf(wait_time)+":00분");
                HashMap<String, String> result_map = new HashMap<String, String>();
                //time_count = wait_time;

                result_map.put(TAG_BANK, m_name);
                result_map.put(TAG_BANK_WAIT_RANK, bank_wait_rank);
                result_map.put(TAG_RESERVE_NUM, reserve_num);
                result_map.put(TAG_NOWRESERVE_NUM, now_reserve_num);


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
    // 값 불러오기
    private String getIDPreference(){
        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        return pref.getString("id", "");

    }



}
