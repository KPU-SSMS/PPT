package www.bank_wait.co.kr.bank_wait;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class regist_bank extends AppCompatActivity {

    private EditText bank_name;
    private EditText bank_lat;
    private EditText bank_lon;
    private EditText bank_address;
    private EditText bank_phone;

    private Button submit;
    private Button cancle;

    String respone_json;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regist_bank);

        bank_name = (EditText)findViewById(R.id.bank_name);
        bank_lat = (EditText)findViewById(R.id.et_latitude);
        bank_lon = (EditText)findViewById(R.id.et_longitude);
        bank_address = (EditText)findViewById(R.id.et_address);
        bank_phone = (EditText)findViewById(R.id.et_phone);

        cancle = (Button)findViewById(R.id.btn_bank_cancle);
        submit = (Button)findViewById(R.id.btn_bank_sub);


        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GetData getData =new GetData();
                getData.execute("http://35.189.148.163/bank_regist.php");

            }
        });
    }

    private class GetData extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;
        String errorString = null;

        @Override
        protected void onPreExecute(){
            super.onPreExecute();

            progressDialog = ProgressDialog.show(getApplicationContext(), "잠시 기다려주세요.", null, true,true);

        }

        @Override
        protected void onPostExecute(String result){
            super.onPostExecute(result);

            progressDialog.dismiss();

            Log.d("", "response -" +result);

            if(result==null){
            }
            else{
                respone_json = result;
                if (respone_json.equals("1")){
                    Toast.makeText(getApplicationContext(),"회원가입에 성공하셨습니다.",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                    startActivity(intent);
                    finish();
                }else if(respone_json.equals("2"))
                {
                    Toast.makeText(getApplicationContext(),"중복된 아이디가 있습니다.",Toast.LENGTH_LONG).show();
                }
            }
        }

        @Override
        protected String doInBackground(String... params){

            String serverURL = params[0];
            serverURL += "?bank_name="+bank_name.getText().toString();
            serverURL += "&bank_lat="+bank_lat.getText().toString();
            serverURL += "&bank_lon="+bank_lon.getText().toString();
            serverURL += "&bank_address="+bank_address.getText().toString();
            serverURL += "&bank_phone="+bank_phone.getText().toString();
            Log.d("URL",serverURL);
            try{
                URL url=new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.connect();

                int responseStatusCode= httpURLConnection.getResponseCode();
                Log.d("", "response code - " +responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode==httpURLConnection.HTTP_OK){
                    inputStream=httpURLConnection.getInputStream();

                }
                else{
                    inputStream=httpURLConnection.getErrorStream();
                }

                InputStreamReader inputStreamReader=new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line=bufferedReader.readLine())!=null){
                    sb.append(line);
                }
                bufferedReader.close();

                return sb.toString().trim();
            }catch (Exception e) {

                Log.d("", "InsertData: Error",e);
                errorString=e.toString();

                return null;
            }
        }
    }
}
