package www.bank_wait.co.kr.bank_wait;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class dialog extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog);
    }
}
