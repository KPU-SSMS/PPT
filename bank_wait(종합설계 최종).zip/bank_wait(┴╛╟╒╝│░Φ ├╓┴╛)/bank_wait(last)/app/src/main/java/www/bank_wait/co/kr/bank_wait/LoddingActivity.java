package www.bank_wait.co.kr.bank_wait;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class LoddingActivity extends AppCompatActivity {

    Thread  splashThread;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lodding);

        splashThread = new Thread() {
            @Override
            public void run() {
                try {
                    synchronized (this) {
                        // Wait given period of time or exit on touch

                        wait(4001);


                    }
                } catch (InterruptedException ex) {
                }

                    Intent intent = new Intent(LoddingActivity.this,LoginActivity.class);
                    startActivity(intent);
                    finish();

            }
        };
        splashThread.start();
    }
}
