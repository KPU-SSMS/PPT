package www.bank_wait.co.kr.bank_wait;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import net.daum.mf.map.api.MapView;

public class MainActivity extends AppCompatActivity {

    Button btn_search_bank;
    Button btn_qrcode;
    Button btn_reserve;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_search_bank = (Button)findViewById(R.id.btn_search_bank);



        btn_search_bank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,KakaoMapActivity.class);
                startActivity(intent);
            }
        });
        btn_qrcode = (Button)findViewById(R.id.btn_qrcode);
        btn_qrcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,QrActivity.class);
                startActivity(intent);
            }
        });
        btn_reserve = (Button)findViewById(R.id.btn_reserve);
        btn_reserve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ReserveActivity.class);
                startActivity(intent);
            }
        });


    }
}
